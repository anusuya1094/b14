#!/bin/bash -ex

DIR=$(dirname "${BASH_SOURCE[0]}")

NAME=$1
ARN=$2

config="$(cat << EOF
- name: $NAME
  type: set-acm
  kind: pki
  storage: s3
  bucket: $STANDARD_BUCKET
EOF
)"

[ -n "$ARN" ] && config+="$(cat << EOF

  arn: "$ARN"
EOF
)"

"$DIR"/lambda.sh pki-set-acm "$config"
