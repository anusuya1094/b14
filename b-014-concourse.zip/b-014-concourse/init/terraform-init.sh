#!/bin/bash -e

export TF_LOG=DEBUG

cd terraform

terraform init \
  -no-color \
  -input=false \
  -backend-config="key=terraform" \
  -backend-config="region=$AWS_REGION" \
  -backend-config="bucket=$STANDARD_BUCKET" \
  -backend-config="dynamodb_table=$STANDARD_DYNAMO"
