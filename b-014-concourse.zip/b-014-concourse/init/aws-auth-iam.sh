#!/bin/bash -ex

DIR=$(dirname "${BASH_SOURCE[0]}")

"$DIR"/lambda.sh aws-auth-iam "$(cat << EOF
- name: $MODULE_NAME
  type: role
  kind: aws-auth-iam
EOF
)"
