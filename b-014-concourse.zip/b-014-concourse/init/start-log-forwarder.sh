#!/bin/bash -e

bash /"$INST"/job-update-logstash-config.sh

cp /"$INST"/logstash.service /etc/systemd/system

systemctl start  logstash
systemctl enable logstash
systemctl status logstash
