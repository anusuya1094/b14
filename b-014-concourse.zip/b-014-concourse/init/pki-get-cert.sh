#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

NAME=$1
URL=$2

"$DIR"/lambda.sh pki-get-cert "$(cat << EOF
- name: $NAME
  type: gen-cer
  kind: pki
  storage: s3
  bucket: $STANDARD_BUCKET
  common_name: $URL
EOF
)"
