#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

POSTGRES_HOST=${1:-$("$DIR"/get-postgres-host.sh)}      || exit $?
export POSTGRES_HOST
POSTGRES_PORT=${2:-$("$DIR"/get-postgres-port.sh)}      || exit $?
export POSTGRES_PORT
POSTGRES_MASTER_PASSWORD=${3:-$("$DIR"/get-postgres-master-password.sh)} || exit $?
export POSTGRES_MASTER_PASSWORD

cat << EOF
input {

$(
  for id in $("$DIR"/get-pipeline-ids.sh) ; do
    tableid=$id envsubst < "$DIR"/../config/logstash-jdbc-input.tmpl
  done
)

}
EOF
