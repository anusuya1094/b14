#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

# set up cronjobs
#
<"$DIR"/../config/crontab.tmpl envsubst | crontab -
