#!/bin/bash -e

env | sort

cat << EOF >> terraform/env.tfvars
project_id            = "$(echo "$PROJECT_ID" | awk '{ print toupper($0) }')"
org_scope             = "$ORG_SCOPE"
func_scope            = "$FUNC_SCOPE"
region                = "$AWS_REGION"
module_name           = "$MODULE_NAME"
environment           = "$ENVIRONMENT"
stage                 = "$STAGE"

standard_bucket       = "$STANDARD_BUCKET"

private_hosted_zone   = "$PRIVATE_HOSTED_ZONE"
public_hosted_zone    = "$PUBLIC_HOSTED_ZONE"
concourse_private_dns = "$CONCOURSE_PRIVATE_DNS"
concourse_public_dns  = "$CONCOURSE_PUBLIC_DNS"
rds_instance_dnsname  = "$CONCOURSE_RDS_DNSNAME"
rds_instance_storage  = "$CONCOURSE_RDS_STORAGE"
rds_instance_class    = "$CONCOURSE_RDS_INSTANCE_CLASS"
rds_version           = "$CONCOURSE_RDS_VERSION"

instance_type         = "$CONCOURSE_INSTANCE_TYPE"
custom_ami_pattern    = "$CUSTOM_AMI_PATTERN"

release               = "$PLATFORM_CONCOURSE_RELEASE"

stackname             = "$CLOUDFORMATION_STACKNAME"

inst                  = "$INST"
EOF

cat terraform/env.tfvars
