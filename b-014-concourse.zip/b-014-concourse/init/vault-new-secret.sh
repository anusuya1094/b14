#!/bin/bash -e

shopt -s extglob
key=${1##+(/)}
# SC2034: value appears unused. Verify use (or export if used externally).
# value=$2

# SC2034: DIR appears unused. Verify use (or export if used externally).
# DIR=$(dirname "${BASH_SOURCE[0]}")

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

secret=$(openssl rand 32 -hex)

vault write "$key" value="$secret" > /dev/null 2>&1 || exit $?

echo "$secret"
