#!/bin/bash -e
set -x
DIR=$(dirname "${BASH_SOURCE[0]}")

NAME=$1
echo $NAME
DOMAIN=$2
MAX_TTL=$3

"$DIR"/lambda.sh pki-role "$(cat << EOF
- name: $NAME
  type: role
  kind: pki
  max_ttl: $MAX_TTL
  not_before_duration: "120s"   # sugg. by vvasilyev per email on 2019-02-04
  skip_hcl: true
  allowed_domains: [ "*.$DOMAIN" ]
  allow_subdomains: true
  allow_glob_domains: true
EOF
)"
