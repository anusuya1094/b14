#!/bin/bash -e

shopt -s extglob
key=${1##+(/)}
# SC2034: value appears unused. Verify use (or export if used externally).
# value=$2

DIR=$(dirname "${BASH_SOURCE[0]}")

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

secret=$("$DIR"/vault-read.sh "$key") || exit $?

if [ -z "$secret" ] ; then

  {
    echo "creating new secret for $key"
    secret=$(openssl rand 32 -hex)

    echo "writing to vault:$key"
    vault write "$key" value="$secret"
  } >&2

fi

echo "$secret"
