#!/bin/bash

DIR=$(dirname "${BASH_SOURCE[0]}")

CONFIG=$1
FILE="$DIR/../config/${CONFIG}.cfg"

[ -z "$CONFIG" ] && echo "/dev/null" && exit
[ ! -f "$FILE" ] && echo "/dev/null" && exit

echo "$FILE"
