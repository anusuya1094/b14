#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

MLAAS_ELASTICSEARCH_HOST=$(
  "$DIR"/get-mlaas-secret-from-vault.sh elasticsearch_host
) || exit $?

echo "$MLAAS_ELASTICSEARCH_HOST"
