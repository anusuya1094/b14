#!/bin/bash

cat << EOF
---

NOTE:
  this script is copying the items listed in \$secrets (see below)
  from $CONCOURSE_NAME/platform_deployment/concourse-init
  to   $CONCOURSE_NAME/concourse-init
  please suspend execution of this script as soon as secrets are being
  provided in $CONCOURSE_NAME/concourse-init from bootstrapping directly

---

EOF

DIR=$(dirname "${BASH_SOURCE[0]}")
# shellcheck source=/dev/null
. "$DIR"/env.sh

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

secrets="
oauth-client-id
oauth-client-secret
"

for secret in $secrets ; do
  "$DIR"/vault-copy.sh \
    "$CONCOURSE_NAME"/platform_deployment/concourse-init/"$secret" \
    "$CONCOURSE_NAME"/concourse-init
done

# conditions for migration may have expired.
# do not signal error in this case
#
exit 0
