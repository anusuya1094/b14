#!/bin/bash -e

# SC2034: DIR appears unused. Verify use (or export if used externally).
#DIR=$(dirname "${BASH_SOURCE[0]}")

URL=$1

arns=$(
  aws acm list-certificates \
    --certificate-statuses ISSUED \
  | jq -r '
    .[][] | select(.DomainName=="'"$URL"'") | .CertificateArn
  ' | head -n 1
)

echo "$arns"
