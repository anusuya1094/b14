#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

FILE="$DIR/../config/crt-revisions.cfg"

if [ -f "$FILE" ] ; then

  # shellcheck source=/dev/null
  . "$FILE"

  echo "$CRT_REVISIONS" | jq -r '
    . | to_entries[] | "\(.key)_revision=\(.value)"
  ' | awk -F= -v format="$1" '{
    gsub("-", "_", $1)
    crt=toupper($1)
    ver=$2
    printf(format, crt, ver) }
  '
fi
