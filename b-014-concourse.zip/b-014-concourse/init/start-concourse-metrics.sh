#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")
# shellcheck source=/dev/null
. "$DIR"/env.sh
# shellcheck source=/dev/null
. "$DIR"/mlaas.env

MODULE_TEMPLATE=$DIR/../config/metricbeat-prometheus.yml.tmpl
MODULE_CONFIG=/etc/metricbeat/modules.d/prometheus.yml.disabled

MLAAS_USERNAME=$("$DIR"/get-mlaas-user-id.sh)           || exit $?
export MLAAS_USERNAME
MLAAS_PASSWORD=$("$DIR"/get-mlaas-endpoint-password.sh) || exit $?
export MLAAS_PASSWORD

envsubst < "$MODULE_TEMPLATE" | tee "$MODULE_CONFIG"

/usr/share/metricbeat/bin/metricbeat \
  -path.home   /usr/share/metricbeat \
  -path.data   /var/lib/metricbeat \
  -path.logs   /var/log/metricbeat \
  -path.config /etc/metricbeat \
  -c /etc/metricbeat/metricbeat.yml \
  -E name="${MODULE_NAME}" \
  modules enable prometheus \
|| exit 66

systemctl restart metricbeat.service
