#!/bin/bash -e

SERVICE=concourse-worker.service

cp /"$INST"/../config/$SERVICE.tmpl /etc/systemd/system/$SERVICE

systemctl start  concourse-worker
systemctl enable concourse-worker
systemctl status concourse-worker
