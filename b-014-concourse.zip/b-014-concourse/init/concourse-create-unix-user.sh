#!/bin/bash -e

# Dedicated System User
adduser --system --group concourse
chown -R concourse:concourse /etc/concourse
chmod 600 /etc/concourse/*_environment
