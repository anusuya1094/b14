#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

# generate internal key pairs
#
"$DIR"/vault-keypair.sh \
  "$VAULT_CONCOURSE_PATH"/concourse-tsa \
  /etc/concourse/tsa_host_key
"$DIR"/vault-keypair.sh \
  "$VAULT_CONCOURSE_PATH"/concourse-worker \
  /etc/concourse/worker_key

ssh-keygen -m PKCS8 -t rsa -q -N '' -f /etc/concourse/session_signing_key

# authorize worker(s)
cp -f /etc/concourse/worker_key.pub /etc/concourse/authorized_worker_keys

# check keys
ls -l /etc/concourse
