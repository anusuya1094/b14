#!/bin/bash -e

shopt -s extglob
key=${1##+(/)}

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

set +e

value=$(vault read "$key" -format=json 2>&1) ; status=$?

set -e

if [ "$value" = "No value found at $key" ] ; then
  value=""
  status=0
fi

if [ $status -eq 0 ] ; then
  echo $value |  jq -r .data.value
else
  echo "$value"
fi

exit  $status
