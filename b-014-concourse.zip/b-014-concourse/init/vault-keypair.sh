#!/bin/bash -e

path=$1
file=$2

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

priv_key_path="${path}-priv-key"
pub_key_path="${path}-pub-key"

priv_key_file="$file"
pub_key_file="$file.pub"

priv_key=$(vault read "$priv_key_path" -format=json | jq -r .data.value)

# shellcheck disable=SC2181
[ $? -ne 0 ] && exit 1

if [ -z "$priv_key" ] ; then

  echo "creating new key for $path"
  ssh-keygen -t rsa -q -N '' -f "$priv_key_file"

  echo "getting private key from $priv_key_file"
  priv_key=$(cat "$priv_key_file")
  echo "writing to vault:$priv_key_path"
  vault write "$priv_key_path" value="$priv_key"

  echo "getting public  key from $pub_key_file"
  pub_key=$(cat "$pub_key_file")
  echo "writing to vault:$pub_key_path"
  vault write "$pub_key_path"  value="$pub_key"

else

  echo "using key parts from vault:$priv_key_path and -pub-key"

  pub_key=$(vault read "$pub_key_path" -format=json | jq -r .data.value)
  # shellcheck disable=SC2181
  [ $? -ne 0 ] && exit 1

  echo "writing private key to $priv_key_file"
  echo "$priv_key" > "$priv_key_file"
  echo "writing public  key to $priv_key_file"
  echo "$pub_key"  > "$pub_key_file"

  chmod 0600 "$priv_key_file"

fi
