#!/bin/bash -e

CONCOURSE=/var/lib/concourse
DIR=$(dirname "${BASH_SOURCE[0]}")
LOGSTASH_ZIP=${LOGSTASH_DOWNLOAD_URL##*/}
LOGSTASH="${LOGSTASH_ZIP%%.zip}"



#install jdk 8 (later versions are not supported by logstash)
#
apt-get install -y openjdk-8-jre



cd $CONCOURSE

#install logstash
#
$DIR/curl-cache.sh $LOGSTASH_DOWNLOAD_URL   || exit $?

unzip -o "$LOGSTASH_ZIP" > /dev/null 2>&1
mv "$LOGSTASH" logstash
rm "$LOGSTASH_ZIP"



#install jdbc connector for postgresql
#
$DIR/curl-cache.sh $POSTGRESQL_DOWNLOAD_URL || exit $?



# install logstash input jdbc
#
cd $CONCOURSE/logstash
bin/logstash-plugin install logstash-input-jdbc
