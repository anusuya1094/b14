#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

SCRIPT=$1

DELAY=70   # start cronjob earliest in $DELAY seconds

SECS=$(date +%s)
SECS=$((SECS + DELAY))
FORMAT="%M %H %d %m"
SCHEDULE=$(
   date -d @$SECS -u +"$FORMAT" 2> /dev/null \
|| date -r $SECS  -u +"$FORMAT"
)

export CERTIFICATE_LOOK_AHEAD=7   # force cert renewal

sed -e '
  s/.*\(cronjob.sh.*\)/#* *       * * * \1/g
  s/.*\(cronjob.*'"$SCRIPT"'.*\)/'"$SCHEDULE"' * \1/
' "$DIR"/../config/crontab.tmpl \
| envsubst | crontab -
