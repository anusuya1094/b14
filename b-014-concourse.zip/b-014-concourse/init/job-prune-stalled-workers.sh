#!/bin/bash -e

export HOME=/root

DIR=$(dirname "${BASH_SOURCE[0]}")
# shellcheck source=/dev/null
. "$DIR"/env.sh


: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

/"$INST"/concourse-admin-login.sh job-prune-workers

stalled=$(fly -t job-prune-workers workers | grep stalled | awk '{print $1}')

for worker in $stalled ; do
  fly -t job-prune-workers prune-worker -w "$worker"
done

/"$INST"/concourse-logout.sh      job-prune-workers
