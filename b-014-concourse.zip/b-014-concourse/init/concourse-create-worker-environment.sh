#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}"); . "$DIR"/env.sh

# Worker Environment Configuration
#
envsubst < "$DIR"/../config/worker_environment.tmpl | tee /etc/concourse/worker_environment

# authorize the worker(s) on the server
#
cp /etc/concourse/worker_key.pub /etc/concourse/authorized_worker_keys
