#!/bin/bash -e

aws dynamodb describe-table --table-name "${STANDARD_DYNAMO}" > /dev/null 2>&1 || \
aws dynamodb create-table   --table-name "${STANDARD_DYNAMO}" \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=10 \
  --key-schema AttributeName=LockID,KeyType=HASH
