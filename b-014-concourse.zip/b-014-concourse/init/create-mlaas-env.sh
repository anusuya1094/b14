#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

cp "$DIR"/../config/mlaas.env.tmpl "$DIR"/mlaas.env
