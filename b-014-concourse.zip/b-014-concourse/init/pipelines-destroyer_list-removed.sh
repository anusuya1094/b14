#!/bin/bash -e
echo -n > $3
while IFS='' read -r line || [[ -n "$line" ]]; do
  if [ -z $(grep '^'$line'$' $2) ] ; then
    echo $line >> $3
  fi
done < "$1"
