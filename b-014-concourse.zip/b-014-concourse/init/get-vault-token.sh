#!/bin/bash -e
# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

TTL=${1:-$TOKEN_SHORT_LEASE}

: "${AWS_DEFAULT_REGION:=$(/"$INST"/get-default-region.sh)}"
export AWS_DEFAULT_REGION

VAULT_TOKEN=$(
  vault login \
    -token-only \
    -method=aws \
    -path="$ORG_SCOPE"."$FUNC_SCOPE".aws-auth."$ENVIRONMENT" \
    header_value="$ORG_SCOPE"."$FUNC_SCOPE".vault."$ENVIRONMENT" \
    role=rle."$ORG_SCOPE"."$FUNC_SCOPE"."${MODULE_NAME}"-runtime."$ENVIRONMENT" region=us-east-1
) || exit $?

export VAULT_TOKEN

vault token renew -increment "$TTL" > /dev/null 2>&1 || exit $?

echo "$VAULT_TOKEN"
