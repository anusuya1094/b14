#!/bin/bash

TEST_JOB=$1

START_TIME=$(date)

STARTED_BUILD=$(
  fly --target "$CONCOURSE_TEAMNAME" trigger-job \
      --job    "$TEST_JOB" \
  || exit $?
)

echo "$STARTED_BUILD"

JOB=${STARTED_BUILD% *}
JOB=${JOB##started }
BUILD=${STARTED_BUILD##* #}

TEST_LOG=${JOB//\//___}___${BUILD}
TEST_STATUS=${2:-/tmp/${TEST_LOG}.status}
TEST_LOG=/tmp/${TEST_LOG}.log

fly --target "$CONCOURSE_TEAMNAME" watch \
    --job    "$JOB" \
    --build  "$BUILD" \
> "$TEST_LOG"

STATUS=$?

END_TIME=$(date)

echo "$STATUS   $JOB   #$BUILD    START: $START_TIME   END: $END_TIME" >> "$TEST_STATUS"

exit $STATUS
