#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")



# Download Concourse + Fly
#
mkdir /temp
ls -ltr /temp
pushd /temp

$DIR/curl-cache.sh $CONCOURSE_DOWNLOAD_URL || exit $?
$DIR/curl-cache.sh $FLY_DOWNLOAD_URL       || exit $?

## Unpack fly and the concourse package
tar zxvf fly-"${CONCOURSE_RELEASE}"-linux-amd64.tgz
tar zxvf concourse-"${CONCOURSE_RELEASE}"-linux-amd64.tgz

## move the concourse package to the desired location
mv concourse /usr/local/concourse

## Add permissions for, and install Fly
chmod 755 fly
mv fly /usr/local/bin/fly

[ -d /usr/local/concourse ] || exit 1
[ -x /usr/local/bin/fly ]   || exit 1

popd
