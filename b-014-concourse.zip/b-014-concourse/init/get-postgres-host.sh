#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

# shellcheck source=/dev/null
. "$DIR"/env.sh

: "${AWS_DEFAULT_REGION:=$("$DIR"/get-default-region.sh)}"
export AWS_DEFAULT_REGION

aws rds describe-db-instances \
  --db-instance-identifier vw-shs-"${MODULE_NAME}"-"${ENVIRONMENT}" \
| jq -r .DBInstances[0].Endpoint.Address
