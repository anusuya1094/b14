#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

"$DIR"/get-mlaas-secret-from-vault.sh user_id
