#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

POSTGRES_MASTER_PASSWORD=$(
  "$DIR"/vault-secret.sh "$VAULT_CONCOURSE_PATH"/postgresql-master-password
)

echo "$POSTGRES_MASTER_PASSWORD"
