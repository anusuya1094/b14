#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

CONCOURSE_ADMIN_PASSWORD=$("$DIR"/get-concourse-admin-password.sh)

USERS="admin:$CONCOURSE_ADMIN_PASSWORD"

TEAMS=$(python3 "$DIR"/teams.py 2> /dev/null)

for team in $TEAMS ; do
  password=$("$DIR"/get-concourse-password.sh "$team")
  USERS+=",${team}:${password}"
done

echo "$USERS"
