#!/bin/bash -ex

#sed -i '$ a supersede domain-name-servers 11.221.252.2, search eu-west-1.compute.internal;' /etc/dhcp/dhclient.conf

VPC_CIDR=$(aws ec2 describe-vpcs \
    --filter Name=tag:Name,Values=vpc."${ORG_SCOPE}"."${FUNC_SCOPE}"."${ENVIRONMENT}" \
    --query 'Vpcs[*].{id:CidrBlock}' --output text
)

VPC_IP=$(echo "$VPC_CIDR" | cut -d"/" -f1)

DNS_RESOLVER=$(awk -F"." '{print $1"."$2"."$3".2"}'<<<"${VPC_IP}")


sed -i '$ a supersede domain-name-servers '"$DNS_RESOLVER"';' /etc/dhcp/dhclient.conf

systemctl restart networking
