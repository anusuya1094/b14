#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

. $DIR/mlaas.env

# some versions of install-beats.sh may need these:
#
export SC2_ASS_GROUP="$SC_ASS_GROUP"
export SC2_CI_NAME="$SC_CI_NAME"

export BUCKET=s3://bkt.$ORG_SCOPE.$FUNC_SCOPE.mlsbeats.$AWS_REGION.$ENVIRONMENT
export INSTALLBEATS=/tmp/install-beats.sh

aws s3 cp $BUCKET/install-beats.sh $INSTALLBEATS
sed -i -e 's/$ENVIRONMENT_/${ENVIRONMENT}_/g' $INSTALLBEATS
chmod 700 $INSTALLBEATS

export VAULT_TOKEN=$($DIR/get-vault-token.sh) || exit $?

# in case this is some kind of "staging" installation, copy the "shared" folder
# in $CONTEXT (OS-FS-ENV) first in order to provide mlaas credentials in vault
#
if [ "$VAULT_SOURCE_PREFIX" != "$VAULT_DESTINATION_PREFIX" ] ; then

  $DIR/vault-copy.sh \
    $VAULT_SOURCE_PREFIX/$CONTEXT/shared \
    $VAULT_DESTINATION_PREFIX/$CONTEXT
fi

bash -x $INSTALLBEATS > /var/log/concourse/install-beats.log 2>&1

#rm -f $INSTALLBEATS
