#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")
TERRAFORM_ZIP=${TERRAFORM_DOWNLOAD_URL##*/}

$DIR/curl-cache.sh $TERRAFORM_DOWNLOAD_URL || exit $?

unzip -o -d /tmp/ "$TERRAFORM_ZIP"
mv /tmp/terraform /usr/local/bin/
rm "$TERRAFORM_ZIP"
