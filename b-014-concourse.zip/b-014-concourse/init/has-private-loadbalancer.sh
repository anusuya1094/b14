#!/bin/bash -ex

aws elb describe-load-balancers \
  --load-balancer-name "$PRIVATE_LOADBALANCER_NAME" \
> /dev/null 2>&1
