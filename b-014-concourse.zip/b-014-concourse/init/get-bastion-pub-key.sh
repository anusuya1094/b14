#!/bin/bash -e

BASTION_PUB_KEY=$(
  aws ssm get-parameter \
    --name /proxy/bless-ca/"${ORG_SCOPE}"-"${FUNC_SCOPE}"-"${ENVIRONMENT}" \
  | jq -r .Parameter.Value
)

echo "$BASTION_PUB_KEY"
