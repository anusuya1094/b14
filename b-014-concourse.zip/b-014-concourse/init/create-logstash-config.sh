#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

$DIR/logstash-get-input.sh
$DIR/logstash-get-filter.sh
$DIR/logstash-get-output.sh
