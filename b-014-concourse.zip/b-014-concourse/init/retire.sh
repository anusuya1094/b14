#!/bin/bash -e

WORKER=$1

CONCOURSE_TSA_HOST=$(/"$INST"/get-tsa-host.sh)

/usr/local/concourse/bin/concourse retire-worker \
  --tsa-host="$CONCOURSE_TSA_HOST:2222" \
  --tsa-public-key=/etc/concourse/tsa_host_key.pub \
  --tsa-worker-private-key=/etc/concourse/worker_key \
  --name="$WORKER"
