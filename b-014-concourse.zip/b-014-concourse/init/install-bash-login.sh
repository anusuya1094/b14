#!/bin/bash -e

cat << EOF > /root/.bash_login
complete -C /root/.local/bin/aws_completer aws

. /$INST/env.sh

export PATH="$PATH:/$INST"
EOF
