#!/bin/bash -e

export HOME=/root

DIR=$(dirname "${BASH_SOURCE[0]}")

# shellcheck source=/dev/null
source "$DIR"/env.sh

CONCOURSE_TEAM=$1

if [ -z "$CONCOURSE_TEAM" ] ; then
   echo -e "Team name argument missing. Syntax: $0 <team_name>" 1>&2
   exit 1
fi

REVISIONS=$(bash "$DIR"/create-version-config.sh 'export %s=%s\n')
export REVISIONS
# shellcheck source=/dev/null
source <(echo "$REVISIONS")   # for replacements in envsubst

# 2nd time, now yaml for passing to master pipeline in generator pipeline
REVISIONS=$(bash "$DIR"/create-version-config.sh '%s: %s\\n')
export REVISIONS

envsubst \
  < "$DIR"/../config/generator-pipeline.yaml.tmpl \
  > "$DIR"/generator-pipeline-"${CONCOURSE_TEAM}".yaml

"$DIR"/concourse-login.sh "$CONCOURSE_TEAM"

#fly --target $CONCOURSE_TEAM pipelines | grep "^$CONCOURSE_TEAM$$" || \
fly --target "$CONCOURSE_TEAM" set-pipeline \
    --config "$DIR"/generator-pipeline-"${CONCOURSE_TEAM}".yaml \
    --pipeline generator-pipeline \
    --non-interactive

fly --target "$CONCOURSE_TEAM" unpause-pipeline \
    --pipeline generator-pipeline

#timeout 10m \
fly --target "$CONCOURSE_TEAM" trigger-job \
    --job generator-pipeline/big_bang \
    --watch \
&
#|| exit $?

"$DIR"/concourse-logout.sh "$CONCOURSE_TEAM"
