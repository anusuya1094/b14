#!/bin/bash -e

export TF_LOG=INFO 

cd terraform

terraform taint \
  -no-color \
  -lock=true \
  aws_launch_template.concourse \
|| exit 0
