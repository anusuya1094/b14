#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

VAULT_TOKEN=$("$DIR"/get-vault-token.sh 30m)
export VAULT_TOKEN

if [ ! -d "/tmp/vault-cleaner/" ]; then
  mkdir /tmp/vault-cleaner/
  mkdir /tmp/vault-cleaner/scripts
fi
cd /tmp/vault-cleaner/

echo "
#!/bin/bash
echo -n > \$3
while IFS='' read -r line || [[ -n \"\$line\" ]]; do
  if [ -z \$(grep '^'\$line'\$' \$2) ] ; then
    echo \$line >> \$3
  fi
done < \"\$1\"
" > scripts/list_removed_tables.sh

echo "
#!/bin/bash
echo -n > \$2
while IFS='' read -r line || [[ -n \"\$line\" ]]; do
 vault list -format=yml \$line | sed 's/^.\{2\}//'> vault_secret_list_temp.txt
 ./scripts/append_path.sh vault_secret_list_temp.txt \$line \$2
done < \"\$1\"
" > scripts/detect_secrets_to_remove.sh

echo "
#!/bin/bash
while IFS='' read -r line || [[ -n \"\$line\" ]]; do
 echo vault delete \$2\$line >> \$3
done < \"\$1\"
" > scripts/append_path.sh

echo "
#!/bin/bash
echo -n > \$3
while IFS='' read -r line || [[ -n \"\$line\" ]]; do
 grep -o \$line\%ID\%.* \$2 | grep \%ID%.* | sed 's/^.*%ID%//' >> \$3
done < \"\$1\"
" > scripts/find_pipeline_names.sh

chmod 700 scripts/*
