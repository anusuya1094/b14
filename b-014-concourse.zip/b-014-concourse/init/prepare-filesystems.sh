#!/bin/bash -e

mkdir /etc/concourse
mkdir /var/lib/concourse
mkdir /var/log/concourse

mkfs -t ext4 /dev/nvme0n1
mount /dev/nvme0n1 /var/lib/concourse
