#!/bin/bash -e

SECRET_KEY=$1

DIR=$(dirname "${BASH_SOURCE[0]}")

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}" || exit $?
export VAULT_TOKEN

MLAAS_SECRET_KEY=${ENVIRONMENT}_mlaas_$SECRET_KEY
MLAAS_SECRET=$(
  "$DIR"/vault-read.sh "$CONCOURSE_NAME"/"$CONTEXT"/shared/"$MLAAS_SECRET_KEY"
) || exit $?

echo "$MLAAS_SECRET"
