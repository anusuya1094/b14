#!/bin/bash -ex

shopt -s extglob
DIR=$(dirname "${BASH_SOURCE[0]}")
# shellcheck source=/dev/null
. "$DIR"/env.sh
DAYS=${1:-$CERTIFICATE_LOOK_AHEAD}   # days before expiry

: "${AWS_DEFAULT_REGION:=$(/"$INST"/get-default-region.sh)}"
export AWS_DEFAULT_REGION

set +e
ARN=$("$DIR"/needs-certificate.sh "$DAYS")
STATUS=$?
set -e

if [ $STATUS -eq 0 ] ; then

  echo "ELB cert expiry less than $DAYS days ahead, needs renewal"

  ARN=$("$DIR"/get-private-certificate.sh "$ARN")

  echo "private ELB certificate ARN: $ARN"

  if "$DIR"/has-private-loadbalancer.sh ; then
    "$DIR"/set-private-loadbalancer-cert.sh "$ARN"
  fi

else
  echo "ELB cert expiry more than $DAYS days ahead, NOT renewed"
fi
