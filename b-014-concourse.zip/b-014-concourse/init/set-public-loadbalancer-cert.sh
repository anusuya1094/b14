#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

CERT_ARN=$1

LOADBALANCER_ARN=$("$DIR"/get-public-loadbalancer-arn.sh)

LISTENER_ARN=$(
  aws elbv2 describe-listeners \
    --load-balancer-arn "$LOADBALANCER_ARN" \
  | jq -r '.Listeners[].ListenerArn'
)

aws elbv2 modify-listener \
  --listener-arn "$LISTENER_ARN" \
  --certificates \
    CertificateArn="$CERT_ARN"

echo "cert \"$CERT_ARN\" attached to elb \"$PUBLIC_LOADBALANCER_NAME\""
