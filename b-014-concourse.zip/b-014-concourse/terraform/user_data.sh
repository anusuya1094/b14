#!/bin/bash -x

exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

id

# installing aws cli and stuff
#
apt-get update
apt-get install -y  \
  git               \
  jq                \
  postgresql-client \
  unzip             \
  zip               \
  python3-pip

  


rm /usr/bin/python
ln -s /usr/bin/python3 /usr/bin/python
mkdir /tmp/aws-cfn-bootstrap-latest
python3 -m pip install --upgrade pip

curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

cp /root/.local/bin/aws /usr/bin
curl https://s3.amazonaws.com/cloudformation-examples/aws-cfn-bootstrap-py3-latest.tar.gz \
| tar xz -C /tmp/aws-cfn-bootstrap-latest --strip-components 1
pip install --upgrade /tmp/aws-cfn-bootstrap-latest

aws s3 ls s3://${standard_bucket}/install.zip
aws s3 cp s3://${standard_bucket}/install.zip /
unzip /install.zip
rm -fr /install.zip

chmod 0755 ${inst}/*.sh ${inst}/log? /test/*.sh
ls -la ${inst}

bash -x /${inst}/post-create.sh

exit_code=$?

/usr/local/bin/cfn-signal  \
  --stack "${stackname}"   \
  --exit-code "$exit_code" \
  --resource ServerASG     \
  --region "${region}"
