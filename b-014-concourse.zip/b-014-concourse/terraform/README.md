# Platform Concourse module for the bootstrapping pipeline

Creates a EC2-based Concourse server containing both the web and worker components including a Postgres DB in AWS RDS.

It can be run in one of three ways using the same remote state file located in a dedicated S3 bucket and the following env variables for AWS credentials `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`:

* locally by running `terraform apply -var-file=preprod.tfvars`
* locally as part of the container-based CodeBuild environment described here: https://devstack.vwgroup.com/confluence/display/DEVICEPLAT/WIP%3A+Bootstrapping+Pipeline+Architecture#WIP:BootstrappingPipelineArchitecture-RunningCodeBuildlocally
* or as part of the actual CodeBuild bootstrapping pipeline described here: https://devstack.vwgroup.com/confluence/display/DEVICEPLAT/WIP%3A+Bootstrapping+Pipeline+Architecture

## Bootstrapping

Add an additional Git remote repo to push changes directly to the bootstrapping pipeline: devstack.vwgroup.com/bitbucket/scm/gitaws/mbb_concourse.git


## Oauth Teams
The teams for a concourse instance are defined in the `teams` directory. the subdirectory structure as it stands is:
```
/teams/${ORG_SCOPE}/${FUNC_SCOPE}-${STAGE}/<team-name>.yaml
```

Under an Organisational scope we can have multiple concourse instances. The name of the concourse instance is based on the **functional_scope** and the **stage** that the instance has been started under.

The team name will be taken from the yaml fine defining the permissions for the specified team. A team permissions might look like so (shs-plint team under sharedservices-plint concourse instance):

```yaml
---
roles:
- name: member
  oauth:
    groups: ["AWS_DP_Developer"]
- name: viewer
  oauth:
    groups: ["AWS_DP_Operator", "AWS_DP_Audit", "AWS_DP_RLSMGR"]
```

For more about the user roles and permissions, please follow [this link](https://concourse-ci.org/user-roles.html).
For more details about the actual Oauth groups we use in concourse for each scope and team please read [these resources](https://devstack.vwgroup.com/confluence/display/DEVICEPLAT/WIP%3A+PM+-+Permissions+in+Concourse)


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| allow_ips |  | list | `<list>` | no |
| bitbucket_repo | OWNER/REPO Bitbucket repositories whose members are allowed to log in. | string | - | yes |
| bitbucket_url | Bitbucket repositories whose members are allowed to log in. | string | - | yes |
| concourse_bind_ip |  | string | `0.0.0.0` | no |
| concourse_bind_port |  | string | `8080` | no |
| concourse_external_url |  | string | - | yes |
| concourse_teamname | Name for the initial team used for the master pipeline. | string | `plaform_deployment` | no |
| concourse_version |  | string | `5.2.0` | no |
| environment | Environment | string | - | yes |
| external_dns_name |  | string | - | yes |
| func_scope | Functional scope | string | - | yes |
| instance_type |  | string | `t2.micro` | no |
| multi_az_rds |  | string | `false` | no |
| org_scope | Organization scope | string | - | yes |
| rds_instance_type |  | string | `db.t2.micro` | no |
| region |  | string | - | yes |
| route53_phz_id | The zone ID of the Route53 Private Hosted Zone. | string | - | yes |
