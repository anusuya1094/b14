#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}") ; . $DIR/../init/env.sh

TEST_PIPELINE=$ORG_SCOPE-$FUNC_SCOPE-platformtest-$ENVIRONMENT
TEST_JOB=master-pipeline/Set-And-Trigger-$TEST_PIPELINE

$DIR/../$INST/concourse-login.sh

$DIR/../$INST/test-job.sh $TEST_JOB

STATUS=$?

$DIR/../$INST/concourse-logout.sh

exit $STATUS
