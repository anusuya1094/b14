curl -Lo yaml2json https://github.com/wakeful/yaml2json/releases/latest/download/yaml2json-linux-amd64 && chmod +x yaml2json && sudo mv yaml2json /usr/local/bin/

fly -t platform_staging login -k -n platform_staging -u platform_staging -p dd5e479fce21bc39c69d24a933a23ba3

#BUILDNO=$(fly -t platform_staging trigger-job -j generator-pipeline/big_bang | sed 's/.*#//g')

fly -t platform_staging trigger-job -j generator-pipeline/big_bang -w
fly -t platform_staging get-pipeline master-pipeline > /tmp/test_mp.yaml

PATHS=$(cat /init/generator-pipeline.yaml  | yaml2json | jq '.resources | .[].source.ssm.paths' | grep -v '^null$' | sed 's/"//g')

result=passed

for param in $(aws ssm get-parameters-by-path --path=$PATHS | jq '.Parameters | .[].Name' | sed 's^.*/^^g' | sed 's/"$//')
   check=$(cat master-pipeline | grep param)
   if [ -z "$check" ]; then
     echo $param is missing
     result=not passed
   fi;

echo test result is $result
